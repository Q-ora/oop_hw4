姓名: 謝宗哲
學號: 408210005
email: steven900412@gmail.com
完成項目:
    1. 實作兩種演算法的FindConvexHull()
    2. 在螢幕上分別顯示兩種演算法的計算時間(brutal force包含排序時間)
    3. 分別在Point和Line兩個class額外定義
       getX(),getY()和getA(),getB(),getC()等成員函式來取得private的內容
    4. 輸出的convex hull points呈現逆時針排序
    5. 結果分別輸出到Output_brutal.txt及Output_Javis.txt
    6. 繳交測資(Input.txt)
    7. 備註: 我是以投影片上面寫的"沒有三個點會在同一條直線上"的假設下實作FindConvexHull的